
const AllUsers = () => {
  return (
    <div>AllUsers</div>
  )
}

export default AllUsers