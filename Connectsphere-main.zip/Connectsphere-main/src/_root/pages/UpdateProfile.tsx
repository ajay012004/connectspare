
const UpdateProfile = () => {
  return (
    <div>UpdateProfile</div>
  )
}

export default UpdateProfile