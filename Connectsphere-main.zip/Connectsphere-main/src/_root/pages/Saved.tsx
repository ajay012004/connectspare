
const Saved = () => {
  return (
    <div>Saved</div>
  )
}

export default Saved